-- CreateTable
CREATE TABLE "Company" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "apiKey" TEXT NOT NULL,
    "contact" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Company_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Computer" (
    "id" TEXT NOT NULL,
    "companyId" TEXT NOT NULL,
    "hostname" TEXT NOT NULL,
    "manufacturer" TEXT,
    "model" TEXT,
    "serialNumber" TEXT,
    "cpu" TEXT,
    "cpuCores" INTEGER,
    "ramGB" DOUBLE PRECISION,
    "diskGB" DOUBLE PRECISION,
    "gpu" TEXT,
    "os" TEXT,
    "osVersion" TEXT,
    "osInstallDate" TIMESTAMP(3),
    "lastBootTime" TIMESTAMP(3),
    "ipAddress" TEXT,
    "macAddress" TEXT,
    "biosVersion" TEXT,
    "notes" TEXT,
    "lastSeen" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Computer_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Company_apiKey_key" ON "Company"("apiKey");

-- AddForeignKey
ALTER TABLE "Computer" ADD CONSTRAINT "Computer_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "Company"("id") ON DELETE CASCADE ON UPDATE CASCADE;
